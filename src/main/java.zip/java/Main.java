import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {
        Tuberia padre = new Tuberia();
        padre.iniciarProceso1();
        padre.iniciarProceso2();

        //extraemos las líneas de tasklist del proceso 1 con un getInputStream;
        InputStream inputProceso1 = padre.proceso1.getInputStream();
        InputStreamReader reader1 = new InputStreamReader(inputProceso1);
        BufferedReader buffer1 = new BufferedReader(reader1);
        String linea;

        //TODO mandamos las lineas de tasklist al getOutputStream de proceso 2 para que las filtre los '.txt'
        try {
            while ((linea = buffer1.readLine()) != null) {
                //TODO anterior
            }
        } catch (IOException e) {
            System.out.println("ERROR EL BUFFER: " + e.getMessage());
        }
    }
}
